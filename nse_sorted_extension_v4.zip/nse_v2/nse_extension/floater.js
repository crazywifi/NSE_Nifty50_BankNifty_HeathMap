// floater.js — injected into page, creates draggable NSE Heatmap window

(function() {
  if (document.getElementById('__nse_heatmap_floater__')) return;

  let INTERVAL = 30000; // default 30s
  let cdTimer = null, autoTimer = null, nextAt = 0;

  // ── Shadow DOM container to isolate styles ──
  const host = document.createElement('div');
  host.id = '__nse_heatmap_floater__';
  host.style.cssText = `
    position: fixed;
    top: 60px;
    right: 20px;
    z-index: 2147483647;
    width: 430px;
    display: flex;
    flex-direction: column;
    font-family: 'Segoe UI', system-ui, sans-serif;
  `;
  document.body.appendChild(host);

  const shadow = host.attachShadow({ mode: 'open' });

  const style = document.createElement('style');
  style.textContent = `
    :host { all: initial; }
    * { margin:0; padding:0; box-sizing:border-box; }

    :root {
      --bg:     #080a0e;
      --panel:  #0e1016;
      --border: #1a1d26;
      --text:   #dde1ec;
      --muted:  #525869;
      --g1: #00e676; --g2: #00c853; --gbg: #071a0e;
      --r1: #ff4444; --r2: #e53935; --rbg: #150505;
      --blue:   #4fc3f7;
      --yellow: #ffd54f;
    }

    #floater {
      width: 430px;
      background: #080a0e;
      border: 1px solid #1a1d26;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 8px 40px rgba(0,0,0,.85), 0 0 0 1px rgba(79,195,247,.08);
      display: flex;
      flex-direction: column;
      font-family: 'Segoe UI', system-ui, sans-serif;
      font-size: 10px;
      color: #dde1ec;
      user-select: none;
      max-height: 90vh;
    }

    /* ── TITLE BAR ── */
    .titlebar {
      background: #0e1016;
      border-bottom: 1px solid #1a1d26;
      cursor: grab;
      flex-shrink: 0;
    }
    .titlebar:active { cursor: grabbing; }

    .tb-row1 {
      display: flex; align-items: center; justify-content: space-between;
      padding: 6px 10px; gap: 8px;
    }
    .brand {
      display: flex; align-items: center; gap: 6px;
      font-size: 12px; font-weight: 700; letter-spacing: 0.3px;
      flex-shrink: 0;
    }
    .brand-dot {
      width: 8px; height: 8px; border-radius: 50%;
      background: linear-gradient(135deg, #00e676, #4fc3f7);
      box-shadow: 0 0 6px #00e676;
    }
    .brand span { color: #4fc3f7; }

    .tb-right {
      display: flex; align-items: center; gap: 6px; flex-shrink: 0;
    }
    .meta {
      display: flex; align-items: center; gap: 4px;
      font-size: 9px; color: #525869; font-family: monospace;
    }
    .live-dot {
      width: 6px; height: 6px; border-radius: 50%;
      background: #00e676; animation: blink 2s infinite;
    }
    .live-dot.idle { background: #525869; animation: none; }
    @keyframes blink {
      0%,100%{opacity:1;box-shadow:0 0 4px #00e676} 50%{opacity:.3;box-shadow:none}
    }
    .countdown { color: #4fc3f7; }
    .win-btns { display: flex; gap: 5px; }
    .btn-close, .btn-min {
      width: 18px; height: 18px; border-radius: 50%;
      border: none; cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      font-size: 10px; font-weight: 700; transition: opacity .15s; flex-shrink: 0;
    }
    .btn-close { background: #ff4444; color: #080a0e; }
    .btn-close:hover { opacity: .8; }
    .btn-min { background: #ffd54f; color: #080a0e; }
    .btn-min:hover { opacity: .8; }

    /* ── REFRESH ROW ── */
    .tb-row2 {
      display: flex; align-items: center;
      padding: 4px 10px 5px;
      gap: 6px; border-top: 1px solid #13151e;
    }
    .refresh-label {
      font-size: 9px; color: #525869; font-family: monospace;
      letter-spacing: .5px; flex-shrink: 0;
    }
    .interval-toggle {
      display: flex;
      background: #080a0e;
      border: 1px solid #2a2d3a;
      border-radius: 5px;
      overflow: hidden;
    }
    .int-btn {
      padding: 3px 14px;
      font-size: 10px; font-weight: 700; font-family: monospace;
      border: none; background: transparent;
      color: #6b7080; cursor: pointer;
      transition: all .15s; letter-spacing: .4px;
    }
    .int-btn + .int-btn { border-left: 1px solid #2a2d3a; }
    .int-btn:hover:not(.active) { color: #dde1ec; background: #141720; }
    .int-btn.active { background: #1a2a40; color: #4fc3f7; }

    /* ── SCOREBOARD ── */
    .scoreboard {
      display: flex;
      border-bottom: 1px solid #1a1d26;
      flex-shrink: 0;
    }
    .score-block {
      flex: 1; padding: 5px 10px;
      border-right: 1px solid #1a1d26;
    }
    .score-block:last-child { border-right: none; }
    .score-label {
      font-size: 8px; font-weight: 700;
      letter-spacing: 1.2px; text-transform: uppercase; margin-bottom: 3px;
    }
    .score-label.n50  { color: #4fc3f7; }
    .score-label.bank { color: #ffd54f; }
    .score-updated {
      font-size: 8px; color: #525869; font-family: monospace;
      margin-top: 2px;
    }
    .pill {
      display: flex; align-items: center; gap: 3px;
      padding: 1px 7px; border-radius: 20px;
      font-size: 11px; font-weight: 700; font-family: monospace;
    }
    .pill.g { background: #071a0e; color: #00e676; border: 1px solid #1a4d2a; }
    .pill.r { background: #150505; color: #ff4444; border: 1px solid #4d1010; }
    .pill .dot { width: 5px; height: 5px; border-radius: 50%; }
    .pill.g .dot { background: #00e676; box-shadow: 0 0 4px #00e676; }
    .pill.r .dot { background: #ff4444; box-shadow: 0 0 4px #ff4444; }

    /* ── SCROLLABLE BODY ── */
    .body {
      overflow-y: auto;
      overflow-x: hidden;
      flex: 1;
    }
    .body::-webkit-scrollbar { width: 4px; }
    .body::-webkit-scrollbar-track { background: #080a0e; }
    .body::-webkit-scrollbar-thumb { background: #1a1d26; border-radius: 2px; }

    /* ── SECTION ── */
    .section-title {
      padding: 4px 10px;
      font-size: 8px; font-weight: 700; letter-spacing: 1.2px;
      text-transform: uppercase;
      background: #0e1016;
      border-bottom: 1px solid #1a1d26;
      position: sticky; top: 0; z-index: 1;
    }
    .section-title.n50  { color: #4fc3f7; }
    .section-title.bank { color: #ffd54f; }

    .grid-wrap { padding: 5px 6px; border-bottom: 1px solid #1a1d26; }

    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(60px, 1fr));
      gap: 3px;
    }

    .cell {
      border-radius: 5px; padding: 4px 5px;
      min-height: 42px; position: relative; overflow: hidden;
      cursor: default; transition: transform .1s;
    }
    .cell:hover { transform: scale(1.05); z-index: 5; }
    .cell.g { background: linear-gradient(140deg,#092918,#051a0d); border:1px solid #1a4528; }
    .cell.r { background: linear-gradient(140deg,#220a0a,#160505); border:1px solid #3d1212; }
    .cell.g.hi  { background: linear-gradient(140deg,#0f3d1e,#082a10); border-color:#2a6638; }
    .cell.g.mid { background: linear-gradient(140deg,#0b3018,#061f0b); border-color:#1e5530; }
    .cell.r.hi  { background: linear-gradient(140deg,#350f0f,#240707); border-color:#5a1818; }
    .cell.r.mid { background: linear-gradient(140deg,#2a0c0c,#1c0606); border-color:#481414; }

    .sym {
      font-family: monospace; font-size: 8px; font-weight: 700;
      letter-spacing: .3px; margin-bottom: 2px;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .cell.g .sym { color: #00e676; }
    .cell.r .sym { color: #ff4444; }
    .price {
      font-size: 8px; font-weight: 600; color: #dde1ec;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 1px;
    }
    .chg { font-family: monospace; font-size: 8px; }
    .cell.g .chg { color: #00c853; }
    .cell.r .chg { color: #e53935; }
    .bar {
      position: absolute; bottom:0; left:0; right:0; height:2px;
      border-radius: 0 0 5px 5px;
    }
    .cell.g .bar { background: linear-gradient(90deg,transparent,#00e676); opacity:.5; }
    .cell.r .bar { background: linear-gradient(90deg,transparent,#ff4444); opacity:.5; }

    .placeholder {
      display: flex; align-items: center; justify-content: center;
      gap: 6px; padding: 16px; color: #525869; font-size: 9px;
    }
    .spinner {
      width:14px;height:14px;
      border:2px solid #1a1d26;border-top-color:#4fc3f7;
      border-radius:50%;animation:spin .6s linear infinite;
    }
    @keyframes spin { to { transform:rotate(360deg) } }
    .err {
      background:#150505;border:1px solid #4d1010;color:#ff4444;
      padding:6px 8px;border-radius:4px;font-size:9px;font-family:monospace;margin:4px;
    }

    /* minimized state */
    .body.hidden { display: none; }
    .scoreboard.hidden { display: none; }
    .sections-hidden .section-title,
    .sections-hidden .grid-wrap { display: none; }
  `;
  shadow.appendChild(style);

  // ── Build HTML ──
  const floater = document.createElement('div');
  floater.id = 'floater';
  floater.innerHTML = `
    <div class="titlebar" id="tb">
      <div class="tb-row1">
        <div class="brand"><div class="brand-dot"></div>NSE <span>Heatmap</span></div>
        <div class="tb-right">
          <div class="meta">
            <div class="live-dot idle" id="ld"></div>
            <span class="countdown" id="cd">↻ 0:30</span>
          </div>
          <div class="win-btns">
            <button class="btn-min" id="btnMin" title="Minimise">–</button>
            <button class="btn-close" id="btnClose" title="Close">✕</button>
          </div>
        </div>
      </div>
      <div class="tb-row2">
        <span class="refresh-label">AUTO REFRESH:</span>
        <div class="interval-toggle">
          <button class="int-btn active" id="btn30s">30s</button>
          <button class="int-btn" id="btn60s">60s</button>
        </div>
      </div>
    </div>

    <div class="scoreboard" id="sb">
      <div class="score-block">
        <div class="score-label n50">NIFTY 50</div>
        <div class="score-nums">
          <div class="pill g"><div class="dot"></div><span id="n50g">—</span></div>
          <div class="pill r"><div class="dot"></div><span id="n50r">—</span></div>
        </div>
      </div>
      <div class="score-block">
        <div class="score-label bank">BANK NIFTY</div>
        <div class="score-nums">
          <div class="pill g"><div class="dot"></div><span id="bng">—</span></div>
          <div class="pill r"><div class="dot"></div><span id="bnr">—</span></div>
        </div>
        <div class="score-updated" id="lu">—</div>
      </div>
    </div>

    <div class="body" id="body">
      <div class="section-title n50">▸ NIFTY 50 STOCKS</div>
      <div class="grid-wrap"><div id="niftyGrid" class="grid">
        <div class="placeholder"><div class="spinner"></div>Loading…</div>
      </div></div>
      <div class="section-title bank">▸ BANK NIFTY STOCKS</div>
      <div class="grid-wrap"><div id="bankGrid" class="grid">
        <div class="placeholder"><div class="spinner"></div>Loading…</div>
      </div></div>
    </div>
  `;
  shadow.appendChild(floater);

  // ── Drag logic ──
  let dragging = false, ox = 0, oy = 0;
  const tb = shadow.getElementById('tb');

  tb.addEventListener('mousedown', e => {
    dragging = true;
    const rect = host.getBoundingClientRect();
    ox = e.clientX - rect.left;
    oy = e.clientY - rect.top;
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });
  function onMove(e) {
    if (!dragging) return;
    let x = e.clientX - ox;
    let y = e.clientY - oy;
    // Clamp to viewport
    x = Math.max(0, Math.min(window.innerWidth  - host.offsetWidth,  x));
    y = Math.max(0, Math.min(window.innerHeight - host.offsetHeight, y));
    host.style.left = x + 'px';
    host.style.top  = y + 'px';
    host.style.right = 'auto';
  }
  function onUp() {
    dragging = false;
    document.removeEventListener('mousemove', onMove);
    document.removeEventListener('mouseup', onUp);
  }

  // ── Minimise / Close ──
  let minimised = false;
  shadow.getElementById('btnMin').addEventListener('click', () => {
    minimised = !minimised;
    const body = shadow.getElementById('body');
    const sb   = shadow.getElementById('sb');
    body.classList.toggle('hidden', minimised);
    sb.classList.toggle('hidden', minimised);
    shadow.getElementById('btnMin').textContent = minimised ? '+' : '–';
  });
  shadow.getElementById('btnClose').addEventListener('click', () => {
    host.style.display = 'none';
    clearInterval(autoTimer);
    clearInterval(cdTimer);
  });

  // ── Interval toggle ──
  function setInterval_(ms, activeId) {
    INTERVAL = ms;
    ['btn30s','btn60s'].forEach(id => shadow.getElementById(id).classList.remove('active'));
    shadow.getElementById(activeId).classList.add('active');
    clearInterval(autoTimer);
    autoTimer = setInterval(refresh, INTERVAL);
    // reset countdown with new interval
    startCountdown();
  }
  shadow.getElementById('btn30s').addEventListener('click', () => setInterval_(30000, 'btn30s'));
  shadow.getElementById('btn60s').addEventListener('click', () => setInterval_(60000, 'btn60s'));

  // ── Countdown ──
  function startCountdown() {
    nextAt = Date.now() + INTERVAL;
    clearInterval(cdTimer);
    cdTimer = setInterval(() => {
      const s = Math.max(0, Math.ceil((nextAt - Date.now()) / 1000));
      shadow.getElementById('cd').textContent = `↻ ${Math.floor(s/60)}:${(s%60).toString().padStart(2,'0')}`;
    }, 500);
  }

  // ── Render ──
  function render(gridId, data) {
    const el = shadow.getElementById(gridId);
    if (!data || !data.length) {
      el.innerHTML = '<div class="err">⚠ No data. NSE may be closed.</div>';
      return;
    }
    // Sort: highest +% at top, most negative -% at bottom
    data = [...data].sort((a, b) => (b.changePer || 0) - (a.changePer || 0));
    const maxAbs = Math.max(...data.map(d => Math.abs(d.changePer || 0)));
    el.innerHTML = data.map(d => {
      const g = d.isPositive === 'Y';
      const cls = g ? 'g' : 'r';
      const abs = Math.abs(d.changePer || 0);
      const intensity = abs >= maxAbs*.66 ? 'hi' : abs >= maxAbs*.33 ? 'mid' : '';
      const sign  = g ? '+' : '';
      const price = (d.lastTradedPrice||0).toLocaleString('en-IN',{maximumFractionDigits:1,minimumFractionDigits:1});
      const pct   = `${sign}${(d.changePer||0).toFixed(2)}%`;
      const sym   = (d.icSymbol||'').replace('NIFTY ','').replace('-BE','');
      return `<div class="cell ${cls} ${intensity}" title="${d.icSecurity||''} ₹${price} ${pct}">
        <div class="sym">${sym}</div>
        <div class="price">₹${price}</div>
        <div class="chg">${pct}</div>
        <div class="bar"></div>
      </div>`;
    }).join('');
  }

  // ── Fetch ──
  async function refresh() {
    const ld = shadow.getElementById('ld');
    ld.classList.remove('idle');
    try {
      const data = await new Promise((res, rej) => {
        chrome.runtime.sendMessage({ type: 'FETCH_DATA' }, r => {
          chrome.runtime.lastError ? rej(chrome.runtime.lastError) : res(r);
        });
      });
      shadow.getElementById('n50g').textContent = data.nifty.green;
      shadow.getElementById('n50r').textContent = data.nifty.red;
      shadow.getElementById('bng').textContent  = data.bank.green;
      shadow.getElementById('bnr').textContent  = data.bank.red;
      render('niftyGrid', data.nifty.data);
      render('bankGrid',  data.bank.data);
      const t = new Date();
      shadow.getElementById('lu').textContent =
        'Updated ' + t.toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
      startCountdown();
    } catch(e) {
      ['niftyGrid','bankGrid'].forEach(id => {
        const el = shadow.getElementById(id);
        if (el) el.innerHTML = '<div class="err">⚠ Fetch failed. Open nseindia.com first.</div>';
      });
    }
    ld.classList.add('idle');
  }

  refresh();
  autoTimer = setInterval(refresh, INTERVAL);
})();
