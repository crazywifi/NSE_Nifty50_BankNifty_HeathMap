// background.js — handles NSE cookie refresh, data fetching, floater toggle

const NSE_HOME  = "https://www.nseindia.com/";
const NIFTY_URL = "https://www.nseindia.com/api/NextApi/apiClient/indexTrackerApi?functionName=getContributionData&&index=NIFTY%2050&&noofrecords=0&&flag=1";
const BANK_URL  = "https://www.nseindia.com/api/NextApi/apiClient/indexTrackerApi?functionName=getContributionData&&index=NIFTY%20BANK&&noofrecords=0&&flag=1";

let cookieReady = false;

async function refreshCookies() {
  try {
    await fetch(NSE_HOME, { credentials: "include" });
    cookieReady = true;
  } catch(e) { cookieReady = false; }
}

async function fetchIndex(url) {
  if (!cookieReady) await refreshCookies();
  try {
    const res = await fetch(url, {
      credentials: "include",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://www.nseindia.com/"
      }
    });
    if (res.status === 401 || res.status === 403) {
      cookieReady = false;
      await refreshCookies();
      const res2 = await fetch(url, { credentials: "include", headers: { "Referer": NSE_HOME } });
      const j = await res2.json();
      return j.data || [];
    }
    const j = await res.json();
    return j.data || [];
  } catch(e) { return []; }
}

function summarize(data) {
  return {
    data,
    green: data.filter(d => d.isPositive === "Y").length,
    red:   data.filter(d => d.isPositive === "N").length,
  };
}

// ── Toggle floater on toolbar click ──
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || !tab.url || tab.url.startsWith("chrome://") || tab.url.startsWith("chrome-extension://") || tab.url.startsWith("about:")) return;
  try {
    // Check if floater already injected
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => !!document.getElementById('__nse_heatmap_floater__')
    });
    const exists = results?.[0]?.result;
    if (exists) {
      // Toggle visibility
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const el = document.getElementById('__nse_heatmap_floater__');
          if (el) el.style.display = el.style.display === 'none' ? 'flex' : 'none';
        }
      });
    } else {
      // Inject the floater
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['floater.js']
      });
    }
  } catch(e) {
    console.error("Injection failed:", e);
  }
});

// ── Message handler for data fetch ──
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "FETCH_DATA") {
    (async () => {
      const [niftyRaw, bankRaw] = await Promise.all([
        fetchIndex(NIFTY_URL),
        fetchIndex(BANK_URL)
      ]);
      sendResponse({ nifty: summarize(niftyRaw), bank: summarize(bankRaw) });
    })();
    return true;
  }
});

refreshCookies();
