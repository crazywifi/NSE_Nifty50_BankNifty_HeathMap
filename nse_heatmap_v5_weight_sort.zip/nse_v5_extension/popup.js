// popup.js

const INTERVAL = 60000; // 1 minute
let cdTimer = null, nextAt = 0, autoTimer = null;

function startCountdown() {
  nextAt = Date.now() + INTERVAL;
  clearInterval(cdTimer);
  cdTimer = setInterval(() => {
    const s = Math.max(0, Math.ceil((nextAt - Date.now()) / 1000));
    const m = Math.floor(s / 60), sec = s % 60;
    document.getElementById('cd').textContent = `↻ ${m}:${sec.toString().padStart(2, '0')}`;
  }, 500);
}

function render(gridId, data) {
  const el = document.getElementById(gridId);
  if (!data || !data.length) {
    el.innerHTML = '<div class="err">⚠ No data. NSE may be closed or blocked.</div>';
    return;
  }
  const maxAbs = Math.max(...data.map(d => Math.abs(d.changePer || 0)));
  el.innerHTML = data.map(d => {
    const g = d.isPositive === 'Y';
    const cls = g ? 'g' : 'r';
    const abs = Math.abs(d.changePer || 0);
    let intensity = '';
    if (abs >= maxAbs * 0.66) intensity = 'hi';
    else if (abs >= maxAbs * 0.33) intensity = 'mid';
    const sign = g ? '+' : '';
    const price = (d.lastTradedPrice || 0).toLocaleString('en-IN', {
      maximumFractionDigits: 1, minimumFractionDigits: 1
    });
    const pct = `${sign}${(d.changePer || 0).toFixed(2)}%`;
    const sym = (d.icSymbol || '').replace('NIFTY ', '').replace('-BE', '');
    return `<div class="cell ${cls} ${intensity}" title="${d.icSecurity || ''} ₹${price} ${pct}">
      <div class="sym">${sym}</div>
      <div class="price">₹${price}</div>
      <div class="chg">${pct}</div>
      <div class="bar"></div>
    </div>`;
  }).join('');
}

async function fetchData() {
  const ld = document.getElementById('ld');
  ld.classList.remove('idle');

  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'FETCH_DATA' }, (response) => {
      if (chrome.runtime.lastError || !response) {
        resolve(null);
      } else {
        resolve(response);
      }
    });
  });
}

async function refresh() {
  const ld = document.getElementById('ld');
  const data = await fetchData();

  if (!data) {
    ['niftyGrid', 'bankGrid'].forEach(id => {
      document.getElementById(id).innerHTML =
        '<div class="err">⚠ Fetch failed — NSE cookies may need refresh.</div>';
    });
    ld.classList.add('idle');
    startCountdown();
    return;
  }

  // Update scoreboard
  document.getElementById('n50g').textContent = data.nifty.green;
  document.getElementById('n50r').textContent = data.nifty.red;
  document.getElementById('bng').textContent  = data.bank.green;
  document.getElementById('bnr').textContent  = data.bank.red;

  // Render grids
  render('niftyGrid', data.nifty.data);
  render('bankGrid',  data.bank.data);

  // Update timestamp
  const t = new Date();
  document.getElementById('lu').textContent =
    t.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  ld.classList.add('idle');
  startCountdown();
}

// Boot
refresh();
autoTimer = setInterval(refresh, INTERVAL);
