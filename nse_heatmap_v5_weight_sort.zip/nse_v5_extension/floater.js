// floater.js — NSE Heatmap v5 with % Change + Weight sort toggle

(function() {
  if (document.getElementById('__nse_heatmap_floater__')) return;

  // ── Weight order maps (index 0 = highest weight) ──
  const NIFTY_WEIGHT = [
    'HDFCBANK','RELIANCE','ICICIBANK','BHARTIARTL','SBIN','INFY','LT','AXISBANK',
    'ITC','KOTAKBANK','M&M','TCS','BAJFINANCE','SUNPHARMA','HINDUNILVR','NTPC',
    'TITAN','MARUTI','BEL','TATASTEEL','ETERNAL','SHRIRAMFIN','HCLTECH','HINDALCO',
    'POWERGRID','ULTRACEMCO','JSWSTEEL','COALINDIA','ONGC','GRASIM','ADANIPORTS',
    'BAJAJ-AUTO','BAJAJFINSV','ASIANPAINT','EICHERMOT','INDIGO','NESTLEIND',
    'SBILIFE','TECHM','DRREDDY','JIOFIN','TRENT','APOLLOHOSP','MAXHEALTH',
    'CIPLA','HDFCLIFE','TATACONSUM','TMPV','WIPRO','ADANIENT'
  ];
  const BANK_WEIGHT = [
    'HDFCBANK','ICICIBANK','SBIN','AXISBANK','KOTAKBANK','FEDERALBNK',
    'INDUSINDBK','BANKBARODA','AUBANK','CANBK','IDFCFIRSTB','PNB','UNIONBANK','YESBANK'
  ];

  function weightRank(sym, weightArr) {
    // Strip common suffixes for matching
    const clean = sym.replace('NIFTY ','').replace('-BE','').trim();
    const idx = weightArr.indexOf(clean);
    return idx === -1 ? 9999 : idx;
  }

  // ── State ──
  let INTERVAL  = 30000;
  let SORT_MODE = 'pct'; // 'pct' | 'weight'
  let lastNiftyData = null;
  let lastBankData  = null;
  let cdTimer = null, autoTimer = null, nextAt = 0;

  // ── Host ──
  const host = document.createElement('div');
  host.id = '__nse_heatmap_floater__';
  host.style.cssText = `
    position:fixed; top:60px; right:20px;
    z-index:2147483647; width:430px;
    display:flex; flex-direction:column;
    font-family:'Segoe UI',system-ui,sans-serif;
  `;
  document.body.appendChild(host);
  const shadow = host.attachShadow({ mode: 'open' });

  // ── Styles ──
  const style = document.createElement('style');
  style.textContent = `
    :host { all:initial; }
    * { margin:0; padding:0; box-sizing:border-box; }

    #floater {
      width:430px; background:#080a0e;
      border:1px solid #1a1d26; border-radius:10px; overflow:hidden;
      box-shadow:0 8px 40px rgba(0,0,0,.85),0 0 0 1px rgba(79,195,247,.08);
      display:flex; flex-direction:column;
      font-family:'Segoe UI',system-ui,sans-serif;
      font-size:10px; color:#dde1ec;
      user-select:none; max-height:90vh;
    }

    /* ── TITLEBAR ── */
    .titlebar {
      background:#0e1016; border-bottom:1px solid #1a1d26;
      cursor:grab; flex-shrink:0;
    }
    .titlebar:active { cursor:grabbing; }

    .tb-row1 {
      display:flex; align-items:center; justify-content:space-between;
      padding:6px 10px; gap:8px;
    }
    .brand { display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; }
    .brand-dot {
      width:8px; height:8px; border-radius:50%;
      background:linear-gradient(135deg,#00e676,#4fc3f7);
      box-shadow:0 0 6px #00e676; flex-shrink:0;
    }
    .brand span { color:#4fc3f7; }
    .tb-right { display:flex; align-items:center; gap:6px; flex-shrink:0; }
    .meta { display:flex; align-items:center; gap:4px; font-size:9px; color:#525869; font-family:monospace; }
    .live-dot { width:6px; height:6px; border-radius:50%; background:#00e676; animation:blink 2s infinite; }
    .live-dot.idle { background:#525869; animation:none; }
    @keyframes blink { 0%,100%{opacity:1;box-shadow:0 0 4px #00e676} 50%{opacity:.3;box-shadow:none} }
    .countdown { color:#4fc3f7; }
    .win-btns { display:flex; gap:5px; }
    .btn-close,.btn-min {
      width:18px; height:18px; border-radius:50%; border:none; cursor:pointer;
      display:flex; align-items:center; justify-content:center;
      font-size:10px; font-weight:700; transition:opacity .15s; flex-shrink:0;
    }
    .btn-close { background:#ff4444; color:#080a0e; }
    .btn-close:hover { opacity:.8; }
    .btn-min  { background:#ffd54f; color:#080a0e; }
    .btn-min:hover  { opacity:.8; }

    /* ── CONTROL ROW (refresh + sort) ── */
    .tb-row2 {
      display:flex; align-items:center; flex-wrap:wrap;
      padding:5px 10px 6px; gap:10px; border-top:1px solid #13151e;
    }
    .ctrl-group { display:flex; align-items:center; gap:5px; }
    .ctrl-label { font-size:9px; color:#525869; font-family:monospace; letter-spacing:.5px; white-space:nowrap; }

    .toggle-group {
      display:flex; background:#060809;
      border:1px solid #2a2d3a; border-radius:5px; overflow:hidden;
    }
    .tog-btn {
      padding:3px 11px; font-size:10px; font-weight:700;
      font-family:monospace; border:none; background:transparent;
      color:#555870; cursor:pointer; transition:all .15s; letter-spacing:.4px;
      white-space:nowrap;
    }
    .tog-btn + .tog-btn { border-left:1px solid #2a2d3a; }
    .tog-btn:hover:not(.on) { color:#dde1ec; background:#141720; }
    .tog-btn.on { background:#162035; color:#4fc3f7; }
    /* weight sort active = amber tint */
    .tog-btn.on.weight-on { background:#1e1800; color:#ffd54f; }

    /* ── SCOREBOARD ── */
    .scoreboard { display:flex; border-bottom:1px solid #1a1d26; flex-shrink:0; }
    .score-block { flex:1; padding:5px 10px; border-right:1px solid #1a1d26; }
    .score-block:last-child { border-right:none; }
    .score-label { font-size:8px; font-weight:700; letter-spacing:1.2px; text-transform:uppercase; margin-bottom:3px; }
    .score-label.n50  { color:#4fc3f7; }
    .score-label.bank { color:#ffd54f; }
    .score-nums { display:flex; gap:5px; align-items:center; }
    .pill { display:flex; align-items:center; gap:3px; padding:1px 7px; border-radius:20px; font-size:11px; font-weight:700; font-family:monospace; }
    .pill.g { background:#071a0e; color:#00e676; border:1px solid #1a4d2a; }
    .pill.r { background:#150505; color:#ff4444; border:1px solid #4d1010; }
    .pill .dot { width:5px; height:5px; border-radius:50%; }
    .pill.g .dot { background:#00e676; box-shadow:0 0 4px #00e676; }
    .pill.r .dot { background:#ff4444; box-shadow:0 0 4px #ff4444; }
    .score-updated { font-size:8px; color:#525869; font-family:monospace; margin-top:2px; }

    /* ── SORT BADGE on section titles ── */
    .section-title {
      padding:4px 10px; font-size:8px; font-weight:700;
      letter-spacing:1.2px; text-transform:uppercase;
      background:#0e1016; border-bottom:1px solid #1a1d26;
      position:sticky; top:0; z-index:1;
      display:flex; align-items:center; justify-content:space-between;
    }
    .section-title.n50  { color:#4fc3f7; }
    .section-title.bank { color:#ffd54f; }
    .sort-badge {
      font-size:8px; font-weight:600; font-family:monospace;
      padding:1px 5px; border-radius:3px; letter-spacing:.3px;
    }
    .sort-badge.pct    { background:#0d1e30; color:#4fc3f7; }
    .sort-badge.weight { background:#1e1800; color:#ffd54f; }

    /* ── BODY ── */
    .body { overflow-y:auto; overflow-x:hidden; flex:1; }
    .body::-webkit-scrollbar { width:4px; }
    .body::-webkit-scrollbar-track { background:#080a0e; }
    .body::-webkit-scrollbar-thumb { background:#1a1d26; border-radius:2px; }
    .body.hidden { display:none; }
    .scoreboard.hidden { display:none; }

    .grid-wrap { padding:5px 6px; border-bottom:1px solid #1a1d26; }
    .grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(60px,1fr)); gap:3px; }

    .cell {
      border-radius:5px; padding:4px 5px; min-height:42px;
      position:relative; overflow:hidden; cursor:default; transition:transform .1s;
    }
    .cell:hover { transform:scale(1.05); z-index:5; }
    .cell.g     { background:linear-gradient(140deg,#092918,#051a0d); border:1px solid #1a4528; }
    .cell.r     { background:linear-gradient(140deg,#220a0a,#160505); border:1px solid #3d1212; }
    .cell.g.hi  { background:linear-gradient(140deg,#0f3d1e,#082a10); border-color:#2a6638; }
    .cell.g.mid { background:linear-gradient(140deg,#0b3018,#061f0b); border-color:#1e5530; }
    .cell.r.hi  { background:linear-gradient(140deg,#350f0f,#240707); border-color:#5a1818; }
    .cell.r.mid { background:linear-gradient(140deg,#2a0c0c,#1c0606); border-color:#481414; }

    .sym { font-family:monospace; font-size:8px; font-weight:700; letter-spacing:.3px; margin-bottom:2px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .cell.g .sym { color:#00e676; }
    .cell.r .sym { color:#ff4444; }
    .price { font-size:8px; font-weight:600; color:#dde1ec; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-bottom:1px; }
    .chg   { font-family:monospace; font-size:8px; }
    .cell.g .chg { color:#00c853; }
    .cell.r .chg { color:#e53935; }
    .bar { position:absolute; bottom:0; left:0; right:0; height:2px; border-radius:0 0 5px 5px; }
    .cell.g .bar { background:linear-gradient(90deg,transparent,#00e676); opacity:.5; }
    .cell.r .bar { background:linear-gradient(90deg,transparent,#ff4444); opacity:.5; }

    /* weight rank badge (top-right of cell) */
    .wrank {
      position:absolute; top:2px; right:3px;
      font-size:7px; font-family:monospace; color:#ffd54f88;
    }

    .placeholder { display:flex; align-items:center; justify-content:center; gap:6px; padding:16px; color:#525869; font-size:9px; }
    .spinner { width:14px; height:14px; border:2px solid #1a1d26; border-top-color:#4fc3f7; border-radius:50%; animation:spin .6s linear infinite; }
    @keyframes spin { to { transform:rotate(360deg) } }
    .err { background:#150505; border:1px solid #4d1010; color:#ff4444; padding:6px 8px; border-radius:4px; font-size:9px; font-family:monospace; margin:4px; }
  `;
  shadow.appendChild(style);

  // ── HTML ──
  const floater = document.createElement('div');
  floater.id = 'floater';
  floater.innerHTML = `
    <div class="titlebar" id="tb">
      <div class="tb-row1">
        <div class="brand"><div class="brand-dot"></div>NSE <span>Heatmap</span></div>
        <div class="tb-right">
          <div class="meta">
            <div class="live-dot idle" id="ld"></div>
            <span class="countdown" id="cd">↻ 0:30</span>
          </div>
          <div class="win-btns">
            <button class="btn-min"   id="btnMin">–</button>
            <button class="btn-close" id="btnClose">✕</button>
          </div>
        </div>
      </div>
      <div class="tb-row2">
        <div class="ctrl-group">
          <span class="ctrl-label">REFRESH:</span>
          <div class="toggle-group">
            <button class="tog-btn on" id="btn30s">30s</button>
            <button class="tog-btn"    id="btn60s">60s</button>
          </div>
        </div>
        <div class="ctrl-group">
          <span class="ctrl-label">SORT:</span>
          <div class="toggle-group">
            <button class="tog-btn on" id="btnSortPct">% Change</button>
            <button class="tog-btn"    id="btnSortWt">Weight</button>
          </div>
        </div>
      </div>
    </div>

    <div class="scoreboard" id="sb">
      <div class="score-block">
        <div class="score-label n50">NIFTY 50</div>
        <div class="score-nums">
          <div class="pill g"><div class="dot"></div><span id="n50g">—</span></div>
          <div class="pill r"><div class="dot"></div><span id="n50r">—</span></div>
        </div>
      </div>
      <div class="score-block">
        <div class="score-label bank">BANK NIFTY</div>
        <div class="score-nums">
          <div class="pill g"><div class="dot"></div><span id="bng">—</span></div>
          <div class="pill r"><div class="dot"></div><span id="bnr">—</span></div>
        </div>
        <div class="score-updated" id="lu"></div>
      </div>
    </div>

    <div class="body" id="body">
      <div class="section-title n50" id="titleN50">
        <span>▸ NIFTY 50 STOCKS</span>
        <span class="sort-badge pct" id="badgeN50">% CHG</span>
      </div>
      <div class="grid-wrap"><div id="niftyGrid" class="grid">
        <div class="placeholder"><div class="spinner"></div>Loading…</div>
      </div></div>
      <div class="section-title bank" id="titleBank">
        <span>▸ BANK NIFTY STOCKS</span>
        <span class="sort-badge pct" id="badgeBank">% CHG</span>
      </div>
      <div class="grid-wrap"><div id="bankGrid" class="grid">
        <div class="placeholder"><div class="spinner"></div>Loading…</div>
      </div></div>
    </div>
  `;
  shadow.appendChild(floater);

  const $ = id => shadow.getElementById(id);

  // ── Render ──
  function render(gridId, data, weightArr) {
    const el = $(gridId);
    if (!data || !data.length) {
      el.innerHTML = '<div class="err">⚠ No data — NSE may be closed.</div>';
      return;
    }

    let sorted;
    if (SORT_MODE === 'weight') {
      sorted = [...data].sort((a, b) => {
        const symA = (a.icSymbol||'').replace('NIFTY ','').replace('-BE','').trim();
        const symB = (b.icSymbol||'').replace('NIFTY ','').replace('-BE','').trim();
        return weightArr.indexOf(symA) - weightArr.indexOf(symB);
      });
    } else {
      // % change: highest positive first, most negative last
      sorted = [...data].sort((a, b) => (b.changePer || 0) - (a.changePer || 0));
    }

    const maxAbs = Math.max(...sorted.map(d => Math.abs(d.changePer || 0)));

    el.innerHTML = sorted.map((d, i) => {
      const g   = d.isPositive === 'Y';
      const cls = g ? 'g' : 'r';
      const abs = Math.abs(d.changePer || 0);
      const lvl = abs >= maxAbs*.66 ? 'hi' : abs >= maxAbs*.33 ? 'mid' : '';
      const sign  = g ? '+' : '';
      const price = (d.lastTradedPrice||0).toLocaleString('en-IN',{maximumFractionDigits:1,minimumFractionDigits:1});
      const pct   = `${sign}${(d.changePer||0).toFixed(2)}%`;
      const sym   = (d.icSymbol||'').replace('NIFTY ','').replace('-BE','');
      const rank  = SORT_MODE === 'weight' ? `<div class="wrank">#${i+1}</div>` : '';
      return `<div class="cell ${cls} ${lvl}" title="${d.icSecurity||''} ₹${price} ${pct}">
        ${rank}
        <div class="sym">${sym}</div>
        <div class="price">₹${price}</div>
        <div class="chg">${pct}</div>
        <div class="bar"></div>
      </div>`;
    }).join('');
  }

  function updateBadges() {
    const isWt = SORT_MODE === 'weight';
    const badgeClass = isWt ? 'weight' : 'pct';
    const badgeText  = isWt ? 'WEIGHT' : '% CHG';
    ['badgeN50','badgeBank'].forEach(id => {
      const b = $(id);
      b.className = `sort-badge ${badgeClass}`;
      b.textContent = badgeText;
    });
  }

  function rerender() {
    updateBadges();
    if (lastNiftyData) render('niftyGrid', lastNiftyData, NIFTY_WEIGHT);
    if (lastBankData)  render('bankGrid',  lastBankData,  BANK_WEIGHT);
  }

  // ── Sort buttons ──
  $('btnSortPct').addEventListener('click', e => {
    e.stopPropagation();
    SORT_MODE = 'pct';
    $('btnSortPct').className = 'tog-btn on';
    $('btnSortWt').className  = 'tog-btn';
    rerender();
  });
  $('btnSortWt').addEventListener('click', e => {
    e.stopPropagation();
    SORT_MODE = 'weight';
    $('btnSortWt').className  = 'tog-btn on weight-on';
    $('btnSortPct').className = 'tog-btn';
    rerender();
  });

  // ── Refresh interval ──
  function setRefreshInterval(ms, activeId) {
    INTERVAL = ms;
    ['btn30s','btn60s'].forEach(id => $(id).classList.remove('on'));
    $(activeId).classList.add('on');
    clearInterval(autoTimer);
    autoTimer = setInterval(refresh, INTERVAL);
    startCountdown();
  }
  $('btn30s').addEventListener('click', e => { e.stopPropagation(); setRefreshInterval(30000,'btn30s'); });
  $('btn60s').addEventListener('click', e => { e.stopPropagation(); setRefreshInterval(60000,'btn60s'); });

  // ── Countdown ──
  function startCountdown() {
    nextAt = Date.now() + INTERVAL;
    clearInterval(cdTimer);
    cdTimer = setInterval(() => {
      const s = Math.max(0, Math.ceil((nextAt - Date.now()) / 1000));
      $('cd').textContent = `↻ ${Math.floor(s/60)}:${(s%60).toString().padStart(2,'0')}`;
    }, 500);
  }

  // ── Minimise / Close ──
  let minimised = false;
  $('btnMin').addEventListener('click', e => {
    e.stopPropagation();
    minimised = !minimised;
    $('body').classList.toggle('hidden', minimised);
    $('sb').classList.toggle('hidden', minimised);
    $('btnMin').textContent = minimised ? '+' : '–';
  });
  $('btnClose').addEventListener('click', e => {
    e.stopPropagation();
    host.style.display = 'none';
    clearInterval(autoTimer);
    clearInterval(cdTimer);
  });

  // ── Drag ──
  let dragging = false, ox = 0, oy = 0;
  $('tb').addEventListener('mousedown', e => {
    if (e.target.closest('.tog-btn,.btn-close,.btn-min')) return;
    dragging = true;
    const r = host.getBoundingClientRect();
    ox = e.clientX - r.left;
    oy = e.clientY - r.top;
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });
  function onMove(e) {
    if (!dragging) return;
    let x = Math.max(0, Math.min(window.innerWidth  - host.offsetWidth,  e.clientX - ox));
    let y = Math.max(0, Math.min(window.innerHeight - host.offsetHeight, e.clientY - oy));
    host.style.left  = x + 'px';
    host.style.top   = y + 'px';
    host.style.right = 'auto';
  }
  function onUp() {
    dragging = false;
    document.removeEventListener('mousemove', onMove);
    document.removeEventListener('mouseup', onUp);
  }

  // ── Fetch ──
  async function refresh() {
    $('ld').classList.remove('idle');
    try {
      const data = await new Promise((res, rej) => {
        chrome.runtime.sendMessage({ type: 'FETCH_DATA' }, r => {
          chrome.runtime.lastError ? rej(chrome.runtime.lastError) : res(r);
        });
      });
      $('n50g').textContent = data.nifty.green;
      $('n50r').textContent = data.nifty.red;
      $('bng').textContent  = data.bank.green;
      $('bnr').textContent  = data.bank.red;
      lastNiftyData = data.nifty.data;
      lastBankData  = data.bank.data;
      rerender();
      $('lu').textContent = new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
      startCountdown();
    } catch(e) {
      ['niftyGrid','bankGrid'].forEach(id => {
        const el = $(id);
        if (el) el.innerHTML = '<div class="err">⚠ Fetch failed — open nseindia.com first.</div>';
      });
    }
    $('ld').classList.add('idle');
  }

  refresh();
  autoTimer = setInterval(refresh, INTERVAL);
})();
